import time
from adafruit_servokit import ServoKit

# Initialize PCA9685 board
kit = ServoKit(channels=16)
kit.servo[1].angle = 120
time.sleep(2)
# Set PWM frequency to control servo speed
kit._pca.frequency = 50  # change 50 to the desired PWM frequency

# Set servo position
kit.servo[0].angle = 90

# Wait for servo to move to desired position
time.sleep(1)

# Change servo speed by changing the PWM frequency
# kit._pca.frequency = 100  # change 100 to the desired PWM frequency for faster speed

# Set servo position again
kit.servo[0].angle = 180

# Wait for servo to move to new position
time.sleep(1)

# Set servo speed back to original PWM frequency for slower speed
# kit._pca.frequency = 50

# Set servo position to initial position
kit.servo[0].angle = 50
