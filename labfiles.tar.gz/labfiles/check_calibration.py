import time
from adafruit_servokit import ServoKit
kit = ServoKit(channels=16)
tilt=125
pan=0
while(True):
    print("enternum bottom")
    num1 = int(input())
    print("enternum top")
    num2 = int(input())
    if(num1>=0 and num2>=0):
        kit.servo[0].angle=num1
        time.sleep(0.5)
        kit.servo[1].angle=num2
