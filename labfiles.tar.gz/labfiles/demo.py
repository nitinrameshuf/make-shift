import time
from adafruit_servokit import ServoKit

# Initialize PCA9685 board
kit = ServoKit(channels=16)
kit.servo[0].angle = 100
kit.servo[1].angle = 120
time.sleep(1)
print("Initializer complete")
c = input()

# Set PWM frequency to control servo speed
kit._pca.frequency = 50  # change 50 to the desired PWM frequency

# kit.servo[0].angle = 50
# kit.servo[1].angle = 150
# time.sleep(0.5)
# kit.servo[0].angle = 160
# kit.servo[1].angle = 150
# time.sleep(0.5)
# kit.servo[0].angle = 160
# kit.servo[1].angle = 90
# time.sleep(0.5)
# kit.servo[0].angle = 50
# kit.servo[1].angle = 90
# time.sleep(0.5)
# kit.servo[0].angle = 50
# kit.servo[1].angle = 150
# time.sleep(0.5)
# kit.servo[0].angle = 100
# kit.servo[1].angle = 120
# time.sleep(0.5)
mo = 8
tim = 0.01
i = 100
j = 120
while(i>50):
    i = i-mo
    kit.servo[0].angle = i
    time.sleep(tim)
while(j<150):
    j = j+mo
    kit.servo[1].angle = j
    time.sleep(tim)
#i = 50 j = 150
time.sleep(0.5)
while(i<160):
    i = i+mo
    kit.servo[0].angle = i
    time.sleep(tim)
#i = 160 j = 150
time.sleep(0.5)
while(j>90):
    j = j-mo
    kit.servo[1].angle = j
    time.sleep(tim)
# i = 160 j = 90
time.sleep(0.5)
while(i>50):
    i = i-mo
    kit.servo[0].angle = i
    time.sleep(tim)
# i = 50 j = 90
time.sleep(0.5)
while(j<150):
    j = j+mo
    kit.servo[1].angle = j
    time.sleep(tim)
# i = 50 j = 150
time.sleep(0.5)
while(i<100):
    i = i+mo
    kit.servo[0].angle = i
    time.sleep(tim)
time.sleep(0.5)
while(j>120):
    j = j-mo
    kit.servo[1].angle = j
    time.sleep(tim)
# i = 100 j = 120
time.sleep(0.5)
while(i<150):
    i = i+mo
    kit.servo[0].angle = i
    time.sleep(tim)
# time.sleep(0.5)
while(j<145):
    j = j+mo
    kit.servo[1].angle = j
    time.sleep(tim)


# time.sleep(0.5)
# while(i<100):
#     i = i+mo
#     kit.servo[0].angle = i
#     time.sleep(tim)
# while(j<120):
#     j = j+mo
#     kit.servo[1].angle = j
#     time.sleep(tim)

