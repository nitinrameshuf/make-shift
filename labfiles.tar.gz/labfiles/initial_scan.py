import time
from adafruit_servokit import ServoKit
kit = ServoKit(channels=16)
# tilt=[180,50,180,50]
# pan=[0,180,0,180]

pan = 0
tilt = 180
kit.servo[0].angle=pan
time.sleep(0.05)
kit.servo[1].angle=tilt

# Instructions                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
#Format (pan,tilt)
#Start (0,180)
# Move b to 180
# Move t to 50
# move b to 0
# move t to 180
# Move both b to 180 and t to  50


for i in range(180):
    kit.servo[0].angle=i
    pan = i
    time.sleep(0.01)

for i in range(180,50,-1):
    kit.servo[1].angle=i
    tilt = i
    time.sleep(0.01)

for i in range(180,0,-1):
    kit.servo[0].angle=i
    pan = i
    time.sleep(0.01)

for i in range(50,180,1):
    kit.servo[1].angle=i
    tilt = i
    time.sleep(0.01)





# def move_cam_single(servo,angle):
#     if (servo == "pan"):
        
#     elif (servo = "tilt"):
        
#     else:
#         print("Error")


