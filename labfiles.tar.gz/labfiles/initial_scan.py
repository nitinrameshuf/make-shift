import time
from adafruit_servokit import ServoKit
kit = ServoKit(channels=16)
# tilt=[180,50,180,50]
# pan=[0,180,0,180]
kit._pca.frequency = 100
pan = 100
tilt = 120
kit.servo[0].angle=pan
time.sleep(0.05)
kit.servo[1].angle=tilt
time.sleep(1)

# Instructions                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
#Format (pan,tilt)
#Start (0,180)
# Move b to 180
# Move t to 50
# move b to 0
# move t to 180
# Move both b to 180 and t to  50


for i in range(180):
    kit.servo[0].angle=i
    pan = i
    time.sleep(0.01)
    print("1")
time.sleep(5)
for j in range(180,50):
    kit.servo[1].angle=j
    tilt = j
    print("2")
    time.sleep(0.01)
time.sleep(5)
for k in range(180,0):
    kit.servo[0].angle=k
    pan = k
    print("3")
    time.sleep(0.01)
time.sleep(5)
for l in range(50,180):
    kit.servo[1].angle=l
    tilt = l
    time.sleep(0.01)
    print("4")




# for i in range(180):
#     kit.servo[0].angle=i
#     pan = i
#     time.sleep(0.01)
# time.sleep(1)
# for i in range(180,50,-2):
#     kit.servo[1].angle=i
#     tilt = i
#     time.sleep(0.01)
# time.sleep(1)
# for i in range(180,0,-2):
#     kit.servo[0].angle=i
#     pan = i
#     time.sleep(0.01)
# time.sleep(1)
# for i in range(50,180,2):
#     kit.servo[1].angle=i
#     tilt = i
#     time.sleep(0.01)
