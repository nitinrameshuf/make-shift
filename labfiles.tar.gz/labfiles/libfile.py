import k4a

# print(k4a.k4a_device_open)