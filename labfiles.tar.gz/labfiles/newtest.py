from adafruit_servokit import ServoKit
import time

# Set up ServoKit instance
kit = ServoKit(channels=16)

# Set the pulse width range to smoothen the servo movement
kit.servo[0].set_pulse_width_range(500, 2500)

kit.servo[0].angle = 50
time.sleep(0.5)
kit.servo[0].angle = 100
time.sleep(0.5)
kit.servo[0].angle = 150
time.sleep(0.5)
kit.servo[0].angle = 100

kit.servo[1].angle = 70
time.sleep(0.5)
kit.servo[1].angle = 120
time.sleep(0.5)
kit.servo[1].angle = 170
time.sleep(0.5)
kit.servo[1].angle = 120
# kit.servo[1].angle = 120
current_position = kit.servo[0].angle
print(f"Yo + {int(current_position)}")
print(f"Yo + {int(kit.servo[1].angle)}")

# # Define function to smoothly move the servo
# def move_servo_smoothly(servo, desired_position):
#     current_position = servo.angle
#     increment = 1 if desired_position > current_position else -1
#     for position in range(current_position, desired_position, increment):
#         servo.angle = position
#         time.sleep(0.01)

# # Move the servo smoothly to the desired position
# desired_position = 50
# move_servo_smoothly(kit.servo[0], desired_position)

# # Cleanup ServoKit resources
# kit.servo[0].angle = 100