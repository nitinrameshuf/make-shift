import time
from adafruit_servokit import ServoKit
kit = ServoKit(channels=16)
tilt=125
pan=0
# kit.servo[0].angle=pan
# kit.servo[8].angle=pan
# time.sleep(1)
# kit.servo[0].angle=90
# kit.servo[8].angle=180
# time.sleep(1)
# kit.servo[0].angle=180
# kit.servo[8].angle=90
# time.sleep(1)
# kit.servo[0].angle=90
kit.servo[8].angle=180
while(True):
    print("enternum")
    num2 = int(input())
    if(num2==1):
        i = 0
        j = 180
        while(i<180 and j > 0):
            kit.servo[0].angle=j
            kit.servo[8].angle=i
            time.sleep(0.05)
            i += 1
            j -= 1
