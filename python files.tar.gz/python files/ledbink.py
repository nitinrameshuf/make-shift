# GPIO library
import Jetson.GPIO as GPIO
 
# Handles time
import time 
 
# Pin Definition
led_pin1 = 37
led_pin2 = 38
led_pin3 = 40

 
# Set up the GPIO channel
GPIO.setmode(GPIO.BOARD) 
GPIO.setup(led_pin1, GPIO.OUT, initial=GPIO.HIGH)
GPIO.setup(led_pin2, GPIO.OUT, initial=GPIO.HIGH)
GPIO.setup(led_pin3, GPIO.OUT, initial=GPIO.HIGH) 
 
print("Press CTRL+C when you want the LED to stop blinking") 
 
# Blink the LED
while True: 
  time.sleep(0.1) 
  GPIO.output(led_pin1, GPIO.HIGH) 
  print("LED is ON")
  time.sleep(0.1) 
  GPIO.output(led_pin1, GPIO.LOW)
  print("LED is OFF")
  time.sleep(0.1) 
  GPIO.output(led_pin2, GPIO.HIGH) 
  print("LED is ON")
  time.sleep(0.1) 
  GPIO.output(led_pin2, GPIO.LOW)
  print("LED is OFF")
  time.sleep(0.1) 
  GPIO.output(led_pin3, GPIO.HIGH) 
  print("LED is ON")
  time.sleep(0.1) 
  GPIO.output(led_pin3, GPIO.LOW)
  print("LED is OFF")