import curses
from adafruit_servokit import ServoKit
kit = ServoKit(channels=16)
# initialize curses
stdscr = curses.initscr()
curses.noecho()     # don't show typed characters
curses.cbreak()     # respond to keys immediately
stdscr.keypad(True) # interpret special keys like arrow keys
motor_step = 6

# 0 -> pan
# 8 - > tilt
pan = 100
tilt = 120
kit.servo[0].angle=pan
kit.servo[1].angle=tilt

try:
    while True:
        # get a single character of user input
        char_k = stdscr.getch()
        if(char_k == ord('s')):
            if(tilt - motor_step>=50):
                tilt = tilt - motor_step
                kit.servo[1].angle=tilt
        elif(char_k == ord('w')):
            if(tilt + motor_step<=180):
                tilt = tilt + motor_step
                kit.servo[1].angle=tilt
        elif(char_k == ord('d')):
            if(pan+motor_step<=179):
                pan = pan + motor_step
                kit.servo[0].angle=pan
        elif(char_k == ord('a')):
            if(pan - motor_step>=1):
                pan = pan - motor_step
                kit.servo[0].angle=pan
        else:
            continue

        # kit.servo[0].angle=j
        # print the character
        # curses.delay_output(200)
        # stdscr.addstr("You entered: " + chr(char) + "\n")
        # stdscr.refresh()
except KeyboardInterrupt:
    pass
finally:
    # clean up curses
    curses.nocbreak()
    stdscr.keypad(False)
    curses.echo()
    curses.endwin()